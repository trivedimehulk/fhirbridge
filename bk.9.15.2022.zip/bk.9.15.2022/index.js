const app = require('express')();
const http = require('http').Server(app);
const io = require('socket.io')(http);
const port = process.env.PORT || 3000;

//vars
const users = [];
const stags = [];


app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

io.on('connection', (socket) => {


  //on stream

  socket.on('stream', function (data) {
    //console.log(data);
    io.emit('stream-to-all', data);
  });

  

  //todo.. fix this fn properly
  socket.on('needNewStg', function (msg) {
    //gen random stg number
    var stgId=Math.floor(Math.random() * 10000);
    //check if exist in array
    //if exists, regen and check
    //if does not exist, regi stg number
    //reply to sender
    stags.push[stgId+"@"+socket.id];
    socket.emit('needNewStg',stgId);
  });

  // on msg
  socket.on('chat message', msg => {
    io.emit('chat message', msg);
  });

  //user dc
  socket.on('disconnect', function () {
    console.log('Got disconnect!' + socket.id);
    io.emit('user dc', socket.id);

    //remove this user from list
    var _existingUsers = users;
    _existingUsers.forEach(function (item, index) {

      //user@socketid
      var socketid = item.split('@')[1];
      if (socketid == socket.id) {
        console.log('removing user ->' + item.split('@')[0])
        //remove this user
        users.splice(index, 1);
      }

    });
  });

  //user joined -> add to array
  socket.on('user joined', msg => {

    //print to console
    console.log('New user joined-> ' + msg);

    //add to array
    //format: username@socketid@stgid
    users.push(msg.split('|')[0] + '@' + socket.id+ '@' + msg.split('|')[1]);

    //send to all
    //format
    //username|list of connected users
    var msgPublish = users.join(", ");

    console.log(msgPublish);

    //send all users to create div for this user
    //include list of other users who are already connected
    //so the user who has just joined gets all  list
    io.emit('user joined', msgPublish);


  });
});

http.listen(port, () => {
  console.log(`Socket.IO server running at http://localhost:${port}/`);
});
